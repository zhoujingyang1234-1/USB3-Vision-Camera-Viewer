# U3V Camera SDK — Linux Customer Package

Pre-built shared libraries and Qt6 GUI for IMX296 USB3 Vision cameras.
Built against Ubuntu 22.04 (glibc 2.35). Forward-compatible with newer
Ubuntu / Debian distributions.

## Package layout

```
V9-SDK-SO-CUS/
├── ubuntu22.04-x64/        # Intel/AMD 64-bit
│   ├── lib/libu3v_cam.so
│   ├── bin/u3v_viewer      # Qt6 GUI
│   ├── include/u3v/*.h     # public API
│   ├── examples/*.c        # sample source
│   └── run_viewer.sh
└── ubuntu22.04-arm64/      # Raspberry Pi / Jetson / ARM SBCs
    └── (same layout)
```

## System requirements

- libusb 1.0 runtime
- Qt6 runtime (only needed for the GUI viewer)

### Tested platforms (ARM64)

| OS | Hardware | Status |
|---|---|---|
| Ubuntu 22.04 LTS | NVIDIA Jetson Orin Nano | ✅ Verified |
| Debian Trixie (13) | Raspberry Pi 5 | ✅ Verified |
| Other glibc 2.35+ distros | — | Should work (forward-compatible) |

The same `ubuntu22.04-arm64/` package runs on all of the above without
recompilation.

### Install runtime dependencies

```bash
sudo apt update
sudo apt install -y libusb-1.0-0 libqt6widgets6
```

## Setup USB permissions (one-time)

USB3 Vision cameras require non-root device access. Install the udev rule.

### Method A: Editor (recommended — works on all terminals)

```bash
sudo nano /etc/udev/rules.d/99-u3v.rules
```

Paste the following single line, then save with `Ctrl+O`, exit with `Ctrl+X`:

```
SUBSYSTEM=="usb", ATTRS{bDeviceClass}=="ef", ATTRS{bDeviceSubClass}=="02", ATTRS{bDeviceProtocol}=="01", MODE="0666", GROUP="plugdev"
```

Then reload udev:

```bash
sudo udevadm control --reload-rules
sudo udevadm trigger
```

### Method B: Heredoc (one-shot, requires unbroken paste)

```bash
sudo tee /etc/udev/rules.d/99-u3v.rules > /dev/null <<'EOF'
SUBSYSTEM=="usb", ATTRS{bDeviceClass}=="ef", ATTRS{bDeviceSubClass}=="02", ATTRS{bDeviceProtocol}=="01", MODE="0666", GROUP="plugdev"
EOF
sudo udevadm control --reload-rules
sudo udevadm trigger
```

### Add yourself to the plugdev group (if needed)

`MODE="0666"` already grants all users read/write, so most setups work
out-of-the-box. If you prefer to lock access to the `plugdev` group:

```bash
sudo usermod -aG plugdev "$USER"
# Log out and back in for the group change to take effect
```

> **Debian Trixie note:** `plugdev` group exists by default; the rule
> above works as-is. Verified on Raspberry Pi 5.

## Run the GUI

Pick the right architecture for your machine (`uname -m`):

```bash
# x86_64
cd ubuntu22.04-x64 && ./run_viewer.sh

# arm64 (aarch64)
cd ubuntu22.04-arm64 && ./run_viewer.sh
```

`run_viewer.sh` sets `LD_LIBRARY_PATH` to find `libu3v_cam.so` next to it.

## Link against the SDK from your own application

```c
// my_app.c
#include <u3v/u3v_sdk.h>
#include <stdio.h>

int main(void) {
    u3v_sdk_init();
    u3v_device_info_t devs[8];
    int n = u3v_discover(devs, 8);
    printf("Found %d U3V camera(s)\n", n);
    u3v_sdk_shutdown();
    return 0;
}
```

Compile with the package's headers and library:
```bash
ARCH_DIR=ubuntu22.04-x64       # or ubuntu22.04-arm64
gcc my_app.c \
    -I$ARCH_DIR/include \
    -L$ARCH_DIR/lib -lu3v_cam \
    -Wl,-rpath,'$ORIGIN/lib' \
    -o my_app
```

The `-Wl,-rpath,'$ORIGIN/lib'` lets the resulting binary find
`libu3v_cam.so` next to itself, so you can ship `my_app` + `lib/`
together without polluting `/usr/lib`.

## Public API headers

See `include/u3v/`:
- `u3v_sdk.h`       — init / shutdown / device discovery
- `u3v_camera.h`    — camera open / control / parameters
- `u3v_stream.h`    — frame grab API
- `u3v_imx296.h`    — IMX296-specific register map
- `u3v_types.h`     — shared types and status codes

## Verify the package

```bash
file ubuntu22.04-x64/lib/libu3v_cam.so
# ELF 64-bit LSB shared object, x86-64, dynamically linked, ...

file ubuntu22.04-arm64/lib/libu3v_cam.so
# ELF 64-bit LSB shared object, ARM aarch64, dynamically linked, ...

nm -D --defined-only ubuntu22.04-x64/lib/libu3v_cam.so | wc -l
# Several hundred exported symbols
```

## Troubleshooting

| Symptom | Fix |
|---|---|
| `libusb_open: Permission denied` | Install udev rule, log out/in |
| `error while loading shared libraries: libQt6Widgets.so.6` | `sudo apt install libqt6widgets6` |
| `error while loading shared libraries: libu3v_cam.so` | Use `run_viewer.sh`, or set `LD_LIBRARY_PATH=lib` |
| `version 'GLIBC_2.34' not found` | Your distro is older than Ubuntu 22.04 — contact us for an Ubuntu 18.04 build |
| GUI shows but camera not listed | `lsusb -v \| grep -A2 "Vision"` to confirm enumeration |
