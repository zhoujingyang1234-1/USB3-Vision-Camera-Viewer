#!/usr/bin/env bash
DIR="$(cd "$(dirname "$0")" && pwd)"
LD_LIBRARY_PATH="$DIR/lib:${LD_LIBRARY_PATH:-}" "$DIR/bin/u3v_viewer" "$@"
