/**
 * u3v_xml.h - GenICam XML download and register map discovery
 *
 * Downloads the GenICam XML descriptor from a U3V camera and
 * extracts register addresses for standard features.
 */
#ifndef U3V_XML_H
#define U3V_XML_H

#include "u3v_camera.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Initialize regmap functions (u3v_regmap_init_imx296 / _ov9281 / _basler /
 * _defaults) live in u3v_sensors.h as of SDK 2.1.0. */

/* Download GenICam XML from camera and populate regmap.
 * Falls back to existing regmap on failure (does not overwrite). */
u3v_status_t u3v_xml_discover_registers(u3v_camera_t *cam);

/* Download raw GenICam XML from camera (caller must free *xml_out).
 * Returns XML size in *xml_size. Handles ZIP decompression. */
u3v_status_t u3v_xml_download(u3v_protocol_t *proto,
                               char **xml_out, uint32_t *xml_size);

#ifdef __cplusplus
}
#endif

#endif /* U3V_XML_H */
