# u3v_cam — Python interface for the U3V Camera SDK

`u3v_cam` is a Python package that wraps the C SDK for USB3 Vision cameras
with the Sony IMX296 sensor.  It uses `ctypes` to call the same shared
library (`u3v_cam.dll` on Windows, `libu3v_cam.so` on Linux) as the C
example programs and the Qt viewer.

The standalone `V9-SDK-PYTHON-CUS` package bundles the native libraries
for Windows x64, Linux x64 and Linux ARM64 inside `u3v_cam/_libs/<platform>/`.
Extract, install Python deps, and run — no build step required.

---

## Requirements

| Component | Version |
|---|---|
| Python  | 3.8 – 3.12 |
| numpy   | required |
| PyQt6 + pyqtgraph | for the live viewer (`pip install u3v_cam[viewer]`) |
| opencv-python | optional; enables `--show` preview in `live_capture.py` |

On Windows you also need:
- WinUSB driver installed for the camera (use Zadig — see
  `WINUSB_DRIVER_INSTALL.md` in the SDK package)
- Microsoft Visual C++ Runtime (already installed on Windows 10/11)

On Linux:
- `libusb-1.0` runtime (`apt install libusb-1.0-0`)
- udev rule for non-root access (`build-tools/pi-build/99-u3v.rules`,
  installed automatically by `install_deps.sh`)

---

## Install

### From the standalone customer package (recommended)

```text
V9-SDK-PYTHON-CUS/
├── u3v_cam/
│   └── _libs/
│       ├── windows-x64/   u3v_cam.dll  + libusb-1.0.dll
│       ├── linux-x64/     libu3v_cam.so.2.0.0
│       └── linux-arm64/   libu3v_cam.so.2.0.0
├── examples/
├── tests/
├── run_basic_capture.{bat,sh}
├── run_live_capture.{bat,sh}
├── run_viewer.{bat,sh}
└── install_deps.{bat,sh}
```

**Windows:**
```bat
unzip V9-SDK-PYTHON-CUS.zip
cd V9-SDK-PYTHON-CUS
install_deps.bat                      :: installs numpy + optional viewer/cv2
run_basic_capture.bat                 :: capture 5 frames, save first to .pgm
run_viewer.bat                        :: live PyQt6 viewer
```

**Linux (Ubuntu 22.04 / Pi 5 / Jetson Orin Nano):**
```bash
unzip V9-SDK-PYTHON-CUS.zip
cd V9-SDK-PYTHON-CUS
chmod +x *.sh
./install_deps.sh
./run_basic_capture.sh
./run_viewer.sh
```

### Override the library location

If you want to use a different `u3v_cam.dll` / `libu3v_cam.so` than the one
bundled in `_libs/`:

```bash
# Windows
set U3V_CAM_DLL=C:\path\to\u3v_cam.dll

# Linux / macOS
export U3V_CAM_LIB=/path/to/libu3v_cam.so.2
```

### As a regular Python package (development)

```bash
cd V9-SDK-PYTHON-CUS
pip install -e .          # core
pip install -e .[viewer]  # core + PyQt6 viewer
pip install -e .[opencv]  # core + cv2 preview
```

---

## Quick start

```python
import u3v_cam

with u3v_cam.Camera() as cam:
    print(cam.info)               # {'manufacturer': ..., 'serial': ..., ...}
    cam.exposure_us = 5000        # 5 ms
    cam.gain = 0
    cam.start()
    for _ in range(60):
        frame = cam.read_frame()  # numpy.ndarray, shape (H, W) uint8 for Mono8
        # ... process frame
    cam.stop()
```

The first `read_frame()` auto-starts the stream if `start()` wasn't called
explicitly.  `with`-statement exit closes everything cleanly.

---

## API at a glance

### Discovery

```python
u3v_cam.list_cameras()
# -> [{'index': 0, 'manufacturer': 'XYZ', 'model': '...', 'serial': '...'}]
```

### `Camera`

| Property | Type | Notes |
|---|---|---|
| `info` | dict | manufacturer, model, serial, firmware, sensor size |
| `width`, `height` | int | live ROI |
| `offset_x`, `offset_y` | int | live ROI offset |
| `pixel_format` | int | use `u3v_cam.PFNC_*` constants |
| `payload_size` | int | bytes per frame (read-only) |
| `exposure_us` | int | exposure in microseconds |
| `gain` | int | sensor gain register (0–480 on IMX296) |
| `frame_rate` | int | target fps |
| `trigger_mode` | bool | trigger enable |
| `temperature` | int | raw temperature register |
| `last_frame_status` | int | trailer status of last grab (0 = OK) |
| `last_frame_block_id` | int | monotonic frame counter from the camera |
| `last_frame_timestamp_ns` | int | per-frame timestamp from the camera |

| Method | Purpose |
|---|---|
| `start()`, `stop()` | acquisition control |
| `read_frame(copy=True)` | grab one frame as `np.ndarray` |
| `set_roi(w, h, ox=0, oy=0)` | bulk ROI update with safe ordering |
| `configure_trigger(on, source, activation, selector)` | full trigger config |
| `software_trigger()` | fire one software trigger |
| `set_strobe(duration, delay, pre_delay)` | strobe output config |
| `find_me_led(on=True)` | toggle find-me LED |
| `set_exposure_auto(enable)` | auto-exposure on/off |
| `flush()` | discard pending USB data |
| `read_register(addr)` / `write_register(addr, val)` | raw GenCP access |
| `close()` | release resources (also via `with`) |

### Iteration

```python
for frame in cam:           # auto-start, infinite loop, Ctrl+C ends
    ...
```

---

## Examples

| File | Description |
|---|---|
| `basic_capture.py` | Discover, open, capture 5 frames, save first as PGM |
| `live_capture.py`  | Continuous capture with FPS / dropped statistics; `--show` enables OpenCV preview |
| `trigger_mode.py`  | Software trigger demo with per-trigger latency timing |
| `roi_exposure.py`  | Sweep ROI / exposure / gain combinations |
| `viewer_pyqt.py`   | Full live viewer with PyQt6 + pyqtgraph (sliders, ROI, trigger) |

Run any of them with `python examples/<file>.py`.

---

## Troubleshooting

**`OSError: Failed to locate u3v_cam shared library`**

The Python package didn't find the C library next to itself.  Either:
- copy `u3v_cam.dll` / `libu3v_cam.so.2.0.0` into the same folder as
  `u3v_cam/_loader.py`, or
- set `U3V_CAM_DLL` / `U3V_CAM_LIB` to the full path of the library.

**`No camera found`**

- Windows: confirm WinUSB is installed (Device Manager → camera shows
  "WinUSB Devices") — use Zadig if not.
- Linux: confirm udev rules are loaded (`ls /etc/udev/rules.d/` should
  contain `99-u3v.rules`) and replug the camera.

**Frame rate is exactly half what was configured**

This was a real bug in SDK 2.0.0 (`libusb` async URB truncation).  Make
sure you're on **2.0.1 or newer** — check `u3v_cam.__version__`.

---

## Performance notes

- `read_frame(copy=True)` does one host-side `memcpy`.  At 1456×1088 Mono8
  60 fps that's ~95 MB/s memory bandwidth — negligible on any modern CPU.
- `read_frame(copy=False)` returns a NumPy view into the SDK's reusable
  buffer.  Cheaper, but the data is overwritten on the next `read_frame`.
  Only use when you immediately consume the frame inside the same loop
  iteration.
- The `Camera` class is **not thread-safe**.  If you need concurrent
  control + grab, do control on the same thread that calls
  `read_frame()`, or use a `threading.Lock`.
